// -- Dentro da classe Carro
	public Carro(String nome, String marca, int ano) {
		this.nome = nome;
		this.marca = marca;
		this.ano = ano;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	// outras funcoes...
