// card = objeto Carta do lacaio que quero baixar
// null = nao ha alvo nesta jogada
Jogada lac = new Jogada(TipoJogada.LACAIO, card, null);
minhasJogadas.add(lac);
