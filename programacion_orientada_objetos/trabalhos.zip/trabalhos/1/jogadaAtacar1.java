// card = objeto Carta de meu lacaio de ataque
// cardAlvo = objeto Carta que será alvo do ataque
Jogada atk = new Jogada(TipoJogada.ATAQUE, card, cardAlvo);
minhasJogadas.add(atk);
