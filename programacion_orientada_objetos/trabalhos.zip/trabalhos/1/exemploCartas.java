// Exemplo de um lacaio com 10 de ataque e 1 de vida, custo de mana = 3.
Carta hp = new Carta (1, "Harry Potter", TipoCarta.LACAIO, 10, 1, 1, 3);
// Exemplo de uma magia de alvo com 6 de dano, custo de mana = 2.
Carta vin = new Carta (2, "Wingardium Leviosa", TipoCarta.MAGIA, TipoMagia.ALVO, 6, 2);
