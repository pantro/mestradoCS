// card = objeto Carta da magia (de area) que quero usar
// null = nao ha alvo especifico nesta jogada
Jogada mag = new Jogada(TipoJogada.MAGIA, card, null);
minhasJogadas.add(mag);
