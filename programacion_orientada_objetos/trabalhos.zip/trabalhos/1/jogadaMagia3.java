// card = objeto Carta da magia (de buff) que quero usar
// cardAlvo = objeto Carta de um lacaio do utilizador que recebera o buff
Jogada mag = new Jogada(TipoJogada.MAGIA, card, cardAlvo);
minhasJogadas.add(mag);
