// card = objeto Carta de meu lacaio de ataque
// null significa que o lacaio esta atacando o heroi do oponente.
Jogada atk = new Jogada(TipoJogada.ATAQUE, card, null);
minhasJogadas.add(atk);
