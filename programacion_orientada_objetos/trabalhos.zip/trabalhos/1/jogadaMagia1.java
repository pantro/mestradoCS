// card = objeto Carta da magia (de alvo) que quero usar
// cardAlvo = objeto Carta de um lacaio do oponente que e o alvo desta magia
Jogada mag = new Jogada(TipoJogada.MAGIA, card, cardAlvo);
minhasJogadas.add(mag);
