// null = nao ha carta sendo usada
// cardAlvo = objeto Carta do lacaio que quero atacar com o poder
Jogada pod = new Jogada(TipoJogada.PODER, null, cardAlvo);
minhasJogadas.add(pod);
