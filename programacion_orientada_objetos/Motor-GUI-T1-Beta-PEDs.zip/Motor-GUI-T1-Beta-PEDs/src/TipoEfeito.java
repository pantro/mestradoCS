/**
* Esta classe é uma enumeração para o jogo LaMa (Lacaios & Magias). Esses efeitos não serão usados no T1, apenas no T2.
* @see java.lang.Object
* @author Rafael Arakaki - MC302
*/
public enum TipoEfeito {
	NADA, PROVOCAR, INVESTIDA, ATAQUE_DUPLO
}
