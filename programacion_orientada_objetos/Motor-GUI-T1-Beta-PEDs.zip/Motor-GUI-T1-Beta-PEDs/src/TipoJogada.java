/**
* Esta classe é uma enumeração para o jogo LaMa (Lacaios & Magias).
* @see java.lang.Object
* @author Rafael Arakaki - MC302
*/
public enum TipoJogada {
	LACAIO, MAGIA, ATAQUE, PODER
};
